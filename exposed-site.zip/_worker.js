// EXPOSED on Cloudflare Workers: serves the app, a Google Places proxy, and a shared report store.
// The app is stored compressed below. Needs: secret GOOGLE_KEY, and a KV namespace bound as DB.
const B64=`
H4sIAH8B12oC/819W3PbSJbmu34FzHILRAmECF5kiRSkcdmusnvKbbftcnWFStEGiSSJFgjAAEhR
RTOiY//CPG3E7Os+7fu+zNPOP6lfst85mQABkrpUTXfEhKskXPJy8uR3rpkJnT56/ubZh5/evtAm
2TQ42zulX1rghmOnJsLa2elEuN7Z6VRkrjacuEkqMqc2y0aN4xoK8+PQnQqnNvfFdRwlWU0bRmEm
QhS79r1s4nhi7g9Fg29MzQ/9zHeDRjp0A+HYppbXa4z8zBlGc5FQw5mfBeLsxV/evnn/4vnpobzd
Ow388EqbJGLk1CZZFqe9w8MRekutcRSNA+HGfmoNo+nhME1b5yN36gc3zitQkxx88MeTrHeNH//S
bTb7R/j/SbO57/lpHLg3TnrtxjUtEYFTS7ObQKQTITIihO/O9npJFGXLRmMw7n01Go36jcYIV/aJ
PbTpZjrLel8deydHJwJ3VOYJ/cM1KBa9r8SA/uE2EV7vK++k5bWadIdaI08MhYub6AoNto6b3WF/
bxAtGqn/ix+Oe4Mo8UTSwJN+7HoeHjWyKO6JcF5P3ZFouIlwG36IeaHnZjNeGKu9f5kKz3frMTgl
krQxjIIoAcsnYip6nptcGUseUC+MsvqF52ZuI6N3Ti0gNtUuDTXUZrOphioHTWN26V8xstYR/ctH
Nhp13c5Ijazl2l27rUbWGQ7bJ+5qJTlZ6ZMIql3+s3rc+3q5k5srMNm7WU7dZOyHvWZ/4A6vxkk0
C73e3E3qRI3RZ8ap+xHuCWw9+yheHNpWR9MZWhpDSzf1lyKYi8wfutqfxEzo5tMEQDdTN0wbqUj8
EdduXAtGIkC42nOXsgM/nKBA1s/EImsAD1HiZn4UYnpCsRrMsiwKl1xZQrooX6kN1o6i4SxtzP3U
HwRiGc0y5lg7XmhpFPieJgcCvhl99bIRjUaATq8VgyFT1w/BkIWU1V63BTD1cwZp7iyLcgj2bFTQ
6L1m08/VXjofL2W1Fl71J3KUfD3yg4CH0k+zJLoSveEsSaAgnhH16pnq0rZO8gdE3dCNezwl5Yd/
i0AOP13tWYD8UslwbxSIRX+MKkRc3wWUw4afiWnaGwqaqBWVblWL/22WZv7opqF0Vi+NXeiqgciu
hQh3tFG0j77duRpxp7MeMV8rlCWu589STPUfttE12kAXoS2nbJz4Xh9XoKTSdxk/UF59GoHEyJ4V
g8mmhflTjGyiU0ZrjhWuDCkQYHKzm4ipopKgXyGX4L1N7w5hKLDQIRgcMU+IjGW1vZOTeFHFjX3M
ZbMsWJaHRDq53AeUqiFFgueh4AKN2l5ZaVxiP5ob+v+F6XgA9wt2FWzvA8gpyI2BSMLXnjVwg+U2
xfng2+CR1tRakt5gECy3hrvBDxQLZ9Pleu46VoembhMJgcjQUYPQSx01rGani2Is4YoTNOu5MHeY
DoYxta+lUzcIlmWEtKmXLeo2umlybSuIrisDIf1C8zHxS9Lmh0zMIIiGVzvZfwdoiG0EshKGrePj
TT5IdrnDLL1bxEuCzOqpwpOWhCZaqTZCPxqen4ghK2YMdza9VT8cb5Da2kFqX2L1CanYLcRICrQ1
pLtHa0h3paRNtufrflS0UEqNtyXBKMcb+NXh3qb4OpuiDAgEPmvhchXmVpq5CYyS5Q+jXDBLo+Dr
f4xgbqnFNetPmC0lNQlirGS51UuSVdWbgnC2WEpt05/6oTJRzf79wIClWWiDTeXGT1nUTCvJlNDt
1gBl6jedBtQt65iE3jyAphIbqPcqdVW2KQMhy90m3vkIrOiq8jq62qXFEgF1LZHH7utxGUjSjdjC
A6NtFyA2WZQPnpXLivvC+KpP9yx26Zf3qx72egrajgoNAacRjtiUtNEqnU3x8GZZNQA7xo0p3Zri
lTVc7hL5gZtUic5lZVtUTnZxhhSs0a8yeUWtarPd7bKT8ICG1YxPo0Tcwb8tR2Lb8DNrNxVheTbZ
L9mAyZaR/VzSfK2H6b32tjW0C0V4LDV/UzowSTTOhT5XVb+F/RTAjiAyvYnveQKagBq8ewJ2uYZZ
grDBZ/FltaNZrZRsauZutFRy9+6ahgf5n8VcPakYsNxf3Jy4bUenNHPk5GxNHeUWllk0G04artRN
sRs2blYcieWcayxy3kFmr038r5F92q7WBzGDKz9rzFKabRFA30m/bOtBXlI2MoTaQvyjlCHad5eV
przEHZdjL3YHShzkJtfu4G4v+xazXw34trCdXi/jSE18IgKEgXOxjSnFku2SO4PYEpb4chQlU8KT
JtyUbGKaDbJw3Zg7QLA4y0SfLQsGSNNJtjnXRuuokGe60aYHyp1Zq6oHxhW/Jw7a4JocgFaKQEsB
AF/nMSxJ0HQdMHL79KOB1vEkEw1pK0HsKNHw/zqcLMLg3G9GQ2eeP/9dBmVb+1vDsKzVHurlt7fV
GjW122YTybd4HYyC3Nm0S+yz1+xrBGIkbRHgSGmOQA2hYZPmdKV92OnvK+bZ0sdu7s5zUASX+SLd
lvRFfyvEJ8NQUhicmyhhsuyo5na7w7M2iUtAoUC0GOnxeqRJYXY3h9pWoSYRqlFry+sJsMlzIjCO
68SNi7k+3hG3kMPCwVGc7ogwqHqP21CDlEWXa5H6bZFTEW6X1flOtbQhUujUisLlQ8SVvDuIzo40
DFlUfqflOSxpV900hmZu8OTj9hZ9cVs4cG/YszmWEgW/YUwiSbZEaIttFBYUotep+i4qSxRc3W46
7gv/K1qDJWfLYGRQ12vdPfIXwuuzoDYL/a3wf0uKUzGdKd5IFEqP5gH5Mlcm6cq4p/8hN8M6XRxo
u9LVki7OWBtyJP+FmLtdFbMndxjfEr/XYd0RqwfQQBDZyHSt9k4P5TrA6aFcDiGHhZY/XD/UfM+p
uXFcw0u6x+PQnWvDwE1Tp0bTU9PcxHcbgTug5YXXKIOybqlETS1pfHVY0zgxfuXUUAR6ildHvokW
Tq3JiSP8hxexC4cQvb5ua7YdnDSOtRPteG43J42jeePo5cn86GX7l9ohCEITaAc69OxlNBW4p8vT
Q/e2/hMhl3ByKtT9Q2ixW1p3bnded2EfJ3Zno/t33ND9BIwCd5yu+5e3D+m+q7Xn9jF+dSZ2K2i0
NBTQOi+7W3R4Gjf6EF6kcRR6ZWbIBw8hB/f2x25w3Ghrx0TZ0esTPJk3upOj+SZNH0U4ExWCDoEg
WnsaJn6cne1B2NJM+/b7p9+9d+AlRF5P/xY/tXQCnrpjoZuD2Wgksp7+Df/GcKIUAxVuEtzo5kiI
tKe/ZN9RixANhmJBCphYgVe6mWbuaNTTX/tpCvGlIlkU4d21xm90c3Iz9kUoevrbCC/VnW5C9q/Q
PdcMIBdUWT3TTdIQCYx4T3+mrsCyKGCDr5vi88yP113y7RTSTJ2PZknoZ7NE6Ku+GvtH52Jv6WPc
c1s3ab0RVSFU4yjwtO/g03raS7g1Wt0T08hA3352A2aIBBqMKJmBADz4TiRTNwRHspsYLXzjhp9n
4NYEVVEqcP2p8OAiz8TKVL218t5euskgmiU06ZqqR3RXO3w9C/3h5PYOX0aZCLQBukuiaLrucuQG
6brPdt7nh4nQvvdDmrUXmAgYsWp3L93pYJaMb+/vR8H6WBNc+5YhdvLu3kU3bqC9JdBob13yujf6
o/WacSh+K0Oro+vm3b0HspIo1J6BrdlGT99iSq8Ag+z2vl7MCS1sfjYGdtnfOzzU3gkMZs6SpaGf
qRbPBoE/1AI/pZlLLe1PICPVCDvKnYvC4AaPI01qvdTUUnio9CLRyFehWnsXF/qHdy9evHzzw/sX
Wo6wAmoFlZfmhZrub9wbhHq09ppoLyMIUwGTSmGa7GcT8B79ccW7Cv4oaBAK+UWpncVJTDJ/KtvU
Xv/nf4SgJLyttCz10Qetf3ShCNNfBCxtqP0r4iMY7Sv/3ha2yCvNZXleK5W+df1kCi2h3dI/La7m
YF9XvLQQyb5wh5N6fWH6hnP20Ypn6aTOQEv0A18ibXHRvJS4WlzYlwWgFhetS4UlVsAbgDXhpwQ9
e2UYuQ767rmznNu9i451bNqtDhqdt+juyGy1bbpr092JeXxENx26eWJ2uVyXbrrmyZPm5ar/sSB7
7pwt/VH9u+cXc8v3Lo25NXbym1XR7zvnApAezUJ2gzT4WPW5ibjETM3MjM2RGSemJ8xsYcJQEd0p
/R8by3eKHQ8pbYJn76xAhONssoLDAwnKFWxPuxbu1R71y+rXNlv4Z2PayBRhQqTxwUTm5gfj01rN
pjaG8JEYRTEgBK77AfyVeErQIccJzt4EaAcmtGiWaW6mnfTsbjzta4OKGeMXnSZX/I6bpEcZgEYO
rQajTUIzjjKWYC3xobkIeSmUmGdhHCEMUoJbOLZUixGgXbup9uvf/52gOgUnvF///r8sdPB0Ngbt
rSNcgi9RMBc0xB8FlNpcQDOQBRDUjp9qgnXQtQ+bT+3KxXnuOgL9CZEOe5jQfhfUxAyCmryl4cQN
xygxia7BX40M5JVkmKQvtXQgoMJ0+h9MZ5Ot5+aV2P40COBSD4NZ6qNlZYFNLYw0xNmJ3Lcz5lq/
/o//c9RpEobI+GOawIFUJPOcZUOY8RCKDsxA9UzDLEmOqc5M/VU4j4rSuWGHJz/RZnEQuWjXYj02
Fsxh2ZM7on0S1BKzjPj8x1mQ85ngAaswC4LyiJtmG/9oxNIJwTjhYjKxMGnKMYHRmo0nYPqRfIL3
gBq5AtQRChLFkqE0YLYDkyiLUo2yPYmp4aUb/vr3/5lpcRKBeeXRauFsOhCJpDa8m1rb7PC/i0tS
VeifsxsShuSiacSLcSIYTc9FgIlifJSevhfZLGamQcoBSsljSRBiND90M7RI7yciiEezwGJBuskJ
o9ByFxtb/K+Q1tx7uyR1LNKJNmJXEnxlNNIcPyO3ipfvRALxRQiW3WjDWRaI5IaIc5PEn7tkod4z
02EvyV3wijLXE5qF9ApgIJGKk53Mg44puVU9bUrBqwlFoRSxGkRLcrdN3JXoB+lvJcgxawRGwLp9
bDabTbIxYBScLB9zgMcd2+xCE0kAAuw07drID6F6CONojqoICVaFdrzmhskbHVUQYVIaQQuBrQSi
hUGjJA/xvYjvmAYeQZf/ET6+UQ6gqdndtZLsIqZGcC80uMEztAMHJ7mBmgHYvRwv1NM0ImGTcqRJ
/l/jHegZiiBQ0lXSYrvpkdLVBkfZ9SaWPpv4LkJen9SFn6SsHkAgmmjlVNLkD5STJ0sRRdeIfjH5
4B4LVZ8UDzpFEAEYzdINab+NP2v5eUsSOk7cmFwm9vBYEp5+LIsOYd8PQSKYAxkolHBKmQgQJ6BO
2aGrSu9t3Oiibzk77AyQYA6i6KoqrriGdziMpjzzWXqXAALc0nfvwTJFOZbbVSR85ybk3Q/RONwf
aToorVLu1CTzmxEryNpBQ8xSpgSO1o02jUhqZyl4zaPPcoPk04ghUeEsE+n9CG3LGeiyjBX69sN1
hE6hBTAOnuo3oVg/YIBIeUlgtSZAL/cDYfGkigBphAhLe3MdorwbUwDhpxIrMZqMwttN7psZJl82
tu6SpJQnHG0MwC+NFzTIW4f19QPEjGxhh+CbnwlPOQkJ+Qgle7oxC68x4zThmZtmElhuBgDJ2vRQ
2pG36AUOWCrFbQwdmkQPQXeb8LVGt8QXC1eruYEu6C5xP2AV+Tlg30GVpMVkXKuYj/yOm43mZUkm
H96tdyMTBPeguBQW9ignoIjolE1LEfSXfMG3wLQ/m+buiJRQT6SwNBkZF5kHIIHaeLjD/bOl8/eG
3DvSLDJAg6xj1qFvUhcSKTQ/5bwFr3CQQHiJe02qmx0jTNyGGOww5J0dhpwY225uztSbfyUDgMBO
hFBPtBJBWyHuwAI4qSJe1VeX+iIHp7126nI+XlJn5D+wV+cpgSFTp+dvyMAJstuYaMgY+Z0ZGTxb
mcF3rhS0kn86lY5wX/mi5KIEOwzYDr50c760cz+CgTwWGWU2Q+VgSXeHeETGwWVPgn4Xr8nT9+Ae
5FgN3JLeYEuWRWxKoOWkxa7q2t2KgiLOK58kNsTI0iwaQm0DJmQ24I1kQnrdLlAv89NQG1xKWglO
pXOMEU9LOqK7S2pvswrfsQvFIyi8aGm57lcP3bJ7U6jejyA948bspnTOWAHLx1OVNdupgGWmlbRX
VJ51DgdGUUDrZbP4fp+2K61i90FW8Tuokyx3ue/SJwi8l398/+ZPVkwnCepBNHSD93BrQaEFNL3K
xLSuQ7BI8P+q0jC68eWLfnGpG0XcnCBuThAkO3nE2lehbmIgdh2S9q4LY7lSAfSPPzhWpw8BnIVz
2oftgzlyUWAdVZPuSeu+ZyxlnSRF4yM/AAipu8SaO46D12boJGneK2L3R6GRwG9PwiUtL+ch+7Uj
64jk3O79+IP5I1UCq2ZDUa+7ZmI4Z+7BNcg1m4bpzsfOFYpvl6gnF1eXDds47HytCh/++LXdbObd
kHRQy2U6R4o4g8J6h0qoB+d8XS5KBRxnLUqGKnlYqkXd9UpdivlmhxhkUTEsU0cWKHUuLqBbZID5
eeYGPhkljLiuY17NdpOyP28RlkFZaQhp0PCU/R8uEqNIq8tZJTbzEOFwmNfP6CXXf5YrCY2HMpOW
hTIbNld+Mfc9VtP57OummJt28/IyJ5XzfA7M/sTilaw6016aj5jnI76wL7+OL1qXhxgmZqNI0YwC
Z7nqE2PWCKWpyG9HztkouBhdOnX+9eVL0ziwqXqOHcrQ9G5nrMn0mEymOQpMEVLY2wvPnK6ZpKsc
6I+d1DnzouGMeGjBS09u3vMmmCipp4Yp0iEVeJ8htBnjgaXitvrhxf7pWe3ycGwOnbP6Ut/Xe/o+
bGof4ntK10FGl2d0OebLGl1+nkW4WV0ML2kov022ZWZ2W7TnRRZvbuwQ5XDqoMTcosReQb5eZI91
3VhPKY01tSSrzlOLmdfTf/37v+l5GYSB1Fw4RWdWGgOcaAvETN24fu2cXV80Lw2LjhvU0bCVBgBx
HU5P0ccrZxnDt+jpm4tfuklrTHh+26qUbg4CD+/vXCYC0D1vgFJtPJtwMyh9HDxpdLQnWmdut6lf
uzmnWnZ7Am1LIQKR09W6QeOJxv/Wqyj+0PGcs0/3L189XnqrYpHqU14dAbBTn5ieGZgLBxyhpoql
M7zMl84eLyermvZ4uVjJBa68yNCvnT1e+sO6Z6zUatfjZbCiFa+iDxoAdZLlHXj+ei01ilvllVO0
V+mxvMr6DdpRvb2yqFGD+6k0lwVUIsMLPK2SmvJyrlqQo7cgkCwvJUWg0y5pySwhd9SRyWLyZP4M
kvskBLLQg0WBixeSsI15ev9q6EThHVOn0Rkb4kMUnuvl4zWQUzbAq42l2nbQsp5oXetIO7Js66TR
sTpax2prNt1/T7B6EjS6eNiygK0GPWxbLe3E6ga4blgnv5TxUZhRWl2pf86N6OfA+Wxl0fcRQo5n
LhhRSE4SXafOx1zdQQbrjyhD/+XLnPbW3MAs0S9jf7/+KOf0ly/MKEu5xGmd0uQGFZHq4EBWpV8y
w29Uu15X/BwYkGa4FqTZB0DZRsMDarix8dDl3lg1UNpeTY0j/QYmxcQM7SIx1/JaBczpNWZEbkop
HtE2thp5rtA0VwDoGE5xUtcfL6mdlW5UIS4n+4eQ+sQ0U1l9JZe8CNcSNvUoJOTLjkqyE0B2aJvj
mJLnTo1RvF765kYOVb+1qmj4w4gFK/ShNXM5rpTIFjQ0lIHBqbNyNVaSWIZvMVqQcDuUyyD+52EX
fNOJPRgARY1nNGRa+DnX8eY5jIr2//6vpq/oMYFrZWp8KQFGg+dau5jAuyYG+R2mQ1mi/X1lik67
zXMd3jiTwBM2hE2uEkM8o3mlVDERQkWpqXCVr1FuksC7B1hhrdamq0BgneQOiuY0zgmbzkAnYvC5
ykrQGsXpYXymGweqcC5/zJKS8s3c7W0jBXS/tcK5s+Tlt/rj+s/6V59/Jg23BFFzN5iJL19+1n9W
q730o1iV+zlf3vuZmPLU4wiWwqBEbSBxQVrhDYjr9wLE1CHDw+QmziKLlhyj6Q8/vHp+vvWkbvSU
7/OcslJhdF03jAPp9XGhOp9w0sbcqGq8bpjjD/4UYfPetY9C1xZeu8lw4nwmNYBIL6HX0Syry3K0
l4wtGWD9uK5/NU7Iz+FYAY9UtEC3n5Vzd9o26IQqtEYokpcfXn9PdkQWW+3JNp1UZHkvbnoTDmnE
S7I1Sp067rULRo0E2Q790I39Q9oSyeGzyMT5Z0c/gAsceeKHd6/IX4ZNCElTH+j7Kd7xkCWRiRVd
GdkEk0/bzbh5TzWfWH9Lo5C0eJVeLw8x9LKGm9TOvqUFl+/4aLb22o1TCU39wGM9uqg4EIFf3gZV
ICnGT1KBC6kCFWM0qbB2a6ZhnR2ylp02jqAHWvhpN11oC9q7a+NNc9iEwjhuHMF54h+/UPljq+ui
FhVqNtlRo+tms9no/KI/QNMt2AxtSLB8kc4GxmqHqH5ayyiJdmH6N+GwWpntbtNYFRgkrjiMBNp+
JqFA0J2zUUUAA94urDHecdTKEzs37kALe9LnKL8TJ2iiDBRcwzN1bP1WxMRbiIE6oGX5sX7geyYI
6+EX64eY2SZVQWxJL2C92SPXC3GudMsv7129N8eoKLdunF/kV6Zq67JHSQlaj1fxhkxPKF/X+b2h
TN8t2qvUS2+pZ3JHKSsmf3RTdytxDzRAVRtxo+RrWRM3nTh6bqz1AzbWRU1OfdURG88Cj5dyaXFW
LlvzXFuAdBEYjIdOvVApSsIePP7xkMe+XJWdVxXYrlYrAzRvbXl4NLfG+/vjYWnjQ35DGx8UykWY
+FC0JZxLcqsor4KcXMgx/2CwPJL2PFe78rFjl6f69ypP9mwOEDAqz/P36tI8ZSTD0KrPKoPSw5/T
g0ODt7E4sq8Nr1o2MYUiXrOFQ+RbPOBruM2slW4rMDTkAKYF9bnj3vrNymNqbagPxZvWHWqjlXNn
E/17qJoLsrEk3GzLdT+HEpg15ojsbkEEgDeFcDysSmE5KkOjHkYGEIGWqjQ6ZXnEqBMYbPB1JYPH
9+8+ynCxvychvc4+skm/x6DTNtSyxlWQvgVW1Blth+vv1T1LqpovXy4ujS1J3BIlGVcVWpHkEU0o
f7PaxkK18U62ceOc3Vip7+3v8y+0taDfhsHWeytbu4AGKvB/5VRYmadjDnXjwr6EetFp4FePOF9J
lOgFc8vKUikOGTk5rDJkNL4RmIGoc/lIhaA0/EesRnryOa0buWz5HoAgGcJvgoifVnCEIZBL+Fk3
jEmaX0qP2OgLIENbI0YNZZKyoykTDJ/7VIcdypJ/oILuvnJMcVko9lfP3vzJWT4Ngt4FJZu6E/vI
tREowa+x8Xtut4rbBi5edkq3DftjqXDD/oW2mzcpD4XfHfymfNuluSf3PlIHFHpZ3XnX4sTUkXXs
UtxF/0uf6ggx2foJeVZ48svrY+uYGsb1ayKqbdlBA8HdE+vktd2W9+oWLhqlwp6onuUGROr5iDJj
tj3pzO3ma7tTuUPf3UnndVvWtany6y5ubHvYbLQRJHYb/A6/n4AsdU0OIH4+gWvYfnhhokrtVCSy
2kwIuH48P2L2dYNuo7OuhVaOrO73LYy6q8ZUbJHk+jnNMvVntyd4Mj9+fcLPPx4FNtEzQVt0RQnE
7mtb8qI5wZ2NeSB+f8Rb1b7axEutyzabAQ3m+HviU5OrdKrPT/LnOxhJLb7PZlk2diXFCgJHPJMt
nkc5i62AL0szyKN4YnUnXRQ7JmZMwNsO81B//p//kaYi8KJkpKt2W3P7hNOjE7TeJMyAQIy9Q22B
OMzppPPxZELu+mUp5xk6wwcmPUlaLoaXMLSU/Vzf25fnn3YUs1FsV7bi8OyTTCvI7Jik49mrD69e
vHcu1luFi+2z662t5f2xxW5rvWAwrbqV+HLJ0Srny6Ae1ZLQxI9lQHxB2wJ107Is2fUlx1zMimra
iY7EPV7iDXQrVTl/VITllIczzvUolEmKdVQGDfgM7ykwG1JiisOuEG7Dih4U+aZSfHOwu9t1dmG7
kyxiNU6v60YppZXXMVYqN7Lur58bgHVVZkbRj1PkE1mVyp3fFW3KHIQB3VLQq7xxNXiC1bKaB+4P
5fOck7reG/6OfuRUTqKpYOI3k+DlHLg7L0XNZy84/+OH8SzjY0mfa3k5+i5PTXr+kyjwROLUpLXI
98jTfm0ZV9U0poOQTtErWx5jI71eqUtTxn0i5k/rFGKokdRULmqvPADJihrTp64xtYobeS6+VH7g
BrXKg2CABy+KzRe8KS2hPRHeduVwNqXWi53NO1L9/JkaWeiW1bdVsXBISbjHy4+l58w7flqtTm5P
UYy3RKwTdutVhQpj6Ms1RAd+Aw8qp6abryxaY8rX9XWSsK0StE5k6pQtm8tguJYL0c/lVJyen6/Y
caxi9XOtVmqbz0hR03RBnatjU9X++TwUlRoEHrRXlGh5MLwqD5CmmtJgOR42skT5+afiFZVPJC7Y
t1EQrKzEuFC7UuaUVNLpYynr9Ipd37UzpZTjNHbqczPNjHUUqtxoLc/7VlKj2rB2ph/Ulcd/rqtU
low3OKqWGVNorme0l4SeVsr8+vf/DdWnc0a1VyhpAXe0WJjMZDr4sNXkfITpOeIcHcIINUSvuXvx
AAORMrEtGLL7bT4Pwxpnt6lhqMdvaa9t3S4Ebp3+HsOucVhIH2hU+VJjpXa+l/LNeQc7ZDP/auM2
DZATsb8vTmG5q8lvcS5KVMll2k3awKpdiW8uwz+pmU+bE6jxyU3crQ/w04F86tQ7c+zypEKUOUFC
Cco1MQjx2ZPXJv54wtvYoTzUGHNqgADv1GmgtY0X3Gzear3hGfc1LKkhRCm6KPmdNzpIItejrV60
Z9yS6xLFcoXG6xUjfzxLaMvnikDHjsinVWmFjgW0tNHlrlyKkg3IhJTREuIZ0f18gdIpts/kogYz
RSAPz98M/iaGhHYgCYEXno2C6urbAIBruPixXmJvG72Ly36xE4dqJSr0lEVo7wJtieIlRSUhtMpL
akk31+tO5Hbca0ueDlkbugOftqfIzSA5oNaC+mnDrrDzcttSjnqxUtil/SJVwH7qbbZXALV8vp0/
b7TzM160agNNwrQVYLsRWb76s9vG5XB5WzkMp9a69JW0ZDvXuuSrigjK23PdBLRxhfkAoos9NsoF
Lhk7WPlpLPXv6n7LxxmUbeu34UXytoMdK6ZyvXTX/oOSE1lNCJQ2JezIFuTrcMVKa+F0/sNt5gbq
ROb6QVosm8oP056qL1CdvYyu5b53wpt2HSVXpBrVy411vo+5G5PjRZ6EGsHs3Jjl3XHyeaf5B5Zz
pkfuiKIQIt7wSLnpx8uYwiaJkvJGKpLrXW7XwKVl3VkOenkIn1pBVLX7m0jkPczy1ZNSZEGtSx6R
utuy308Va0IhvFTrFhqbNdgKzIaqytevPm14Jq8jUkBqQ2WuEqg88aF+cWUOLzf988DfXpXSMNRH
d64f8dnui6vL6uJRiY/DQ5I12l5nrP5Ax1JuWf/dXoIm53pFNZT0cg+VrS0lVrK92Nvgwru8Kzl+
SEaup9Hz+clJry33RSRbrNBktLJjkU5ujtR//fd/g0Cd67evrsnhqS2CXjHcfNEtseKkvORWtfb8
VYsjMvbFbtUdLXhq0Y6oIvkEDCpsFLwbaKBsoJTgVMgasgU+b5mP4VNZ823Nh6Sy2Bag+BBdFbZD
Pfm41qM/FIJJFh8jFqEHR3WQnL3FldTf+vby4sbc7lz2LxkOJRCPl4/Qyv5+scv1rH2+GbqTq13S
unRLAfp7OstIo2OMFBFXHptLV0RtoxKx0zS/dZYjGPrCP/+zc7FHHjyFLOh0YucdfpZbAUjPsbI8
PZzYYNXFhU5xjZ5vT+Yb2vE55G2mOkXp8l4aMc6qyKvLy0KGAynDMmrOURpu+I35R4SOAaZqGE1b
2DZCZqIfwmysSpExPbMeL69WzjpArlXVWJXJwdXmfgoKD/qYMeL1s0kU0ZZZWmAnK474HUx1S6mQ
3gYDf5z4ecR+zvw7lR9IKw8Z/fGxVOqQS1aIPY1i6ULKsRZEuPmkyPdnFCGrfVKfNurkW4oAkbwH
ueBwrktqlONQ3TxUtFzV+rLG2b18e0Dwm7OVfCpip/DONUJcMbScq+aezMhssNbNNE+eLr6hg6Sk
qxST6VNX9M2bMpt591utU0FHnJR5XYXYiwUfcOlpO89Xl05W185yAMYJrZkQl3IC7qIdzskMgnuj
TegoX4jR/zbiPfEA4u88872m3BMPpPxpeKPOZxbMLseak5h9yo34gw2tsSn7uzKT31qjtQd4tTML
mo3J1bxSCdBgZ94zz1rsHMLzHDPqhKd2PZEn2wsUedsjo4iS+ruw+fBQx+xKXRZuj4RGETtOuIt4
evN4Ga764wixKDUY3jWADdthaw5Hgy5nYkz4VY70Iznq3D1fkCeMKhrJEUl9S1s4EPL4gZAZQTGv
lcE2nQWZT2e73OFQxMCaP3XH4vBr04q9UW2TqDesJdyAY+aYzijT4cP88zMp/fEJPrzOX/RQ58Dp
LLUMWm60m2iWKJNI3wHJiiPt8mSwT2cPpxEbylNOhOY2YuenzyrfAmMnpDJmPnw0iBZy3NFVreoK
b39FP/98b+3sFdjOByI9Hgh910AeBcq/SWCqo+O4p0NxySyb0Hnx00Om+uxTcfCBnGLnQldZQz2m
A0SeOq6DW3lx2V+vq9JJFRINZ1M86L66lnpl9OihWki9MqSOXa9sjiPajU55OO+sub/PPoHj4IqU
dp6eCB26kydt1JaGxJ/W4c3gXu6E4HtjSUl0kSS6YZHeeKb+BokutTjVzD/1cmMV2+vyFAhvTZrp
B+t9gXJvUqVLaT4qvRaWJMzj5IK8h+xSKu89+u+39YgoKu8/UCBZTkU2oU9QvX3z/oNu0vfQRJL2
lrr6JFyDxgtlA0sCRcMr+oe0J0FfmfTVtN5Gn7TBwJKdcvK2coAr9xHIQ+gXPtBqL8cMwfeCgHO5
v//o24v17eWteHgb0FdPtXxzjxQSqrNGBSORY6+pu0CUQ/cH3hZ+09nAWW/GJIRSl/DkMR6SbeHd
T0Q48pMpndRDY1M/W9OQb7dxlvOe4gKfEQI1uI/NjH/G/HNEcmbGCd3Qx116ZETNbEGuDn3kpReK
a42gXafs46v3b/KsbhHHPeHTYiyu+U5OPhKoDg/wF2Jkdppij5694pXH1J1De6gdLaW9KyLdsXsl
X6z4B8MH7EHARINP1OApngNLEmIJPVzxDhZMD2VFKU85o1NvndbJrbPzUzSDUZMnpJPiNCXhZK4i
QPruIKVM6AsfidBSGYbJr6a5aXkat/pFAH8PKlxoLAqpNJnVIHSUDdNW29FVriwX+SYgPFXbgG7Z
eNOXc8ffyyrvbSIU86vyZqTfoJA2j2zmGim5TyPlFe9WSbcd+tzLFbkSlX4RWcpIk9dggajKAuxW
Zjg3wOU/s3TMSwX3p2rpQ6S1sw+Inq5otnb6TD+tZ5HMcqxQI1dW5KdiEEHTh1NKuThL42pswFBJ
fnuEy0k/RHa0e1t+cYxjheBciHL8DKe6vCrAqm15L5fUCawNd9nfcfRq7WdS2knE5zrczIZt6L3a
1gZWvbbaOqqVH1gpdU4fUt+VMqyzfraNwz+Xzqyu/pCnC+8/2/V4+WdpNWj9udQhRFQ5pUlSO1uv
CLCf0qE1F3XdpWxMlSc0DevdErMB50dYxxcnGdQQ6VTFXZWVe05awi+HopxMKSaQE811o5DY5Qri
cftpVJcPo7rls6iy5oe1eG2vq5RT2gcb3n0lVUp+/iAQ01S6+lUxeDpMojRFhPVhpY38oXLZybOu
5Ga3Qjc3XzZamDewuDe0bLTgZaN/cjb2/qz18PBDFXQKXXfmZO9OxMpEWTJ36CtOpZ0n7+Z0ZHWJ
F/P+1mZBOhF745R2Smd8BCXjzagyOlcOKnvUWb6H9N2F711yFtPJ1jelo+Glrko6g5cy6ncemU/m
+/ulQ+m7QFVeAtlE1TvZB9nAIuG9jah3NGz1gUf6hOO7fHlDfdprIDT1PRj6kqPgj+ZI7XlXCoyZ
Xd3Okme2FrsyW4s8s6WWUZP5rUmtxb1JrT3Oof6WrPrdsP5vlEZXZvDeLPqndfqJlHD2mL/5sKpt
J6PatR30Ugi+kYqSOBnl2S4S1iLHtEsH7250/VHuNvVQKGoWvrqiEmB5KzViMU6VWVn9pgR96QMo
Mj9fVvpKKJel02Eci5DmeNh+atqpJuM644o2Ee7+eMDTIKjr9G3s0kF9F0bEYmK/9+HxZtF4HIg6
5ZlM16Kt6iDKovavDGO9yzt2qjvmQQh0gFGizrxyYkWh6Tr0sQV23q+c0s5vCrZcivikt2fkYaIr
Q7TCQd7lz9SXsNu0tc7kOj1imNwT4Rp8al9+DxNKZwUL8OULFTWkvixzSx5NQZ18QYPOrV/sGNul
CQfXaZqenzi2CQW7XJljmcrPtTbgxF+zJUbSV6XqOlWXakg3eUbVjkBnRwf9NL7g7i/Q0eWlk5sK
WNkg+ImZV7xu2JcYw8SgD8Y3Gn2iqWGveON5udhBqdjBAReTpZZynPyzCB65AiIKfsgeOfR8uSZH
FROLPyiY/uhnk9LmNcNYKhc9d9lX651dCt88hkdTigJe85811Ys/bCq/0OE1ppH6Oyh0a/AnHOiD
QKmxhoAb8nc+6xfL4o+g9D7xJX2j7C8QXFD7det4FS+MT2ZEmy2ym15zZZbKq3A4f2mvLs2lN1N/
xKLVaZoI4Egz6MPZwB82BuIXH9NptUzr2MRPuL+l001yhj5EdQbHafO8jpmcsEPWa5Zkhj+D9Y4U
nVjc9nkPKaHyz8KUhDSQiYngkYO6xjKwWKNZxYBI5INCWink58OG6LroZhuc6m8PYAj0He8CnImD
hum7n5nFFKcZU4QYcOwsFz2Bpz7a+Yt5U1z/ZEJ/9xLyEKofK9F5GGZ65ce9R492tCs3jpqcTzVz
HW5K22nKvweD+vi5u3peYBp5Qp0C5GM1RsHruvEwLpAvIblADYy/fBlbaHrjbM7CKUbfGFsL07sp
HvyEBzcS4GOLyGHlxsknd5DWvYVxdry/X7lf39wYhqzk6BO9n4tx+f2Z3SyKzHWWRHXrUJ39/bGF
KTCW/KuMDv5zEo7Ee3/rLWOnKjxFvqxx0jLlDcxa06zLymWMnaMIEH7gkRtE0tZfs13S80AIzuId
rF+O84XSUop3cwr6m5wwlkoq//rXdBbL7aMbZrVSQJ4yPWoaqiXmYp6FuXPM/dt4zRZ5cdroHO2Y
DymtJY6jPbAun5uqCNu61Na3tLK7EuR+L4cQsEiytwG8J01j6S3OmudwiSGlNxys141efovWr90E
AQGdWpWZ2gdNI9z0IX3vnC3dgyqyx1XMfXlijKWAK8uLIM/FyJ0FGeyHAA+iGM5v7I5ZVxOJJs0x
BSTKyMhMbp/+1If8swtw2eivfCDg4D+M/v8BCtKUuil9AAA=
`.replace(/\s/g,'');
const J=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{'content-type':'application/json','cache-control':'no-store'}});
const clean=(s,n)=>String(s||'').replace(/[<>]/g,'').trim().slice(0,n);
const FL=['food','buffet','fees','staff','hygiene','package','contract','equip'];
const sha=async t=>{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t));return[...new Uint8Array(b)].slice(0,8).map(x=>x.toString(16).padStart(2,'0')).join('')};
const rd=async(env,k)=>{try{return JSON.parse(await env.DB.get(k)||'[]')}catch(e){return[]}};
const place=async(env,id,sess)=>{const r=await fetch('https://places.googleapis.com/v1/places/'+id+'?sessionToken='+encodeURIComponent(sess||''),{headers:{'X-Goog-Api-Key':env.GOOGLE_KEY,'X-Goog-FieldMask':'id,displayName,formattedAddress,addressComponents,rating,userRatingCount'}});
const d=await r.json();const c=(d.addressComponents||[]).find(a=>(a.types||[]).includes('locality'));
return{id:d.id,name:d.displayName&&d.displayName.text,address:d.formattedAddress,city:c?c.longText:'',country:'Germany',rating:d.rating||null,count:d.userRatingCount||0}};
export default{async fetch(req,env){const u=new URL(req.url),ip=req.headers.get('CF-Connecting-IP')||'x';
if(u.pathname==='/api/autocomplete'){const q=(u.searchParams.get('q')||'').slice(0,80);if(q.length<3)return J([]);
const r=await fetch('https://places.googleapis.com/v1/places:autocomplete',{method:'POST',headers:{'Content-Type':'application/json','X-Goog-Api-Key':env.GOOGLE_KEY},body:JSON.stringify({input:q,sessionToken:u.searchParams.get('s'),includedRegionCodes:['de'],languageCode:'en'})});
const d=await r.json();return J((d.suggestions||[]).filter(x=>x.placePrediction).map(x=>{const p=x.placePrediction,f=p.structuredFormat||{};return{id:p.placeId,name:(f.mainText&&f.mainText.text)||p.text.text,sub:(f.secondaryText&&f.secondaryText.text)||''}}))}
if(u.pathname==='/api/place'){const id=u.searchParams.get('id')||'';if(!/^[\w-]+$/.test(id))return J({error:'bad id'},400);
const p=await place(env,id,u.searchParams.get('s'));
if(u.searchParams.get('add')==='1'&&p.name){const all=await rd(env,'venues');if(!all.find(x=>x.gid===id)){all.push({id:'g'+id,gid:id,name:clean(p.name,120),city:clean(p.city,60)||'Germany',country:'Germany',type:'Venue',claimed:false,real:1,g:p.rating?[p.rating,p.count]:null});await env.DB.put('venues',JSON.stringify(all.slice(-2000)))}}
return J(p)}
if(u.pathname==='/api/data')return J({reports:await rd(env,'reports'),venues:await rd(env,'venues')});
if(u.pathname==='/api/venue'&&req.method==='POST'){let b;try{b=await req.json()}catch(e){return J({error:'bad'},400)}
if(!/^u\d{5,20}$/.test(String(b.id||''))||clean(b.name,120).length<2||clean(b.city,60).length<2)return J({error:'invalid'},400);
if(await env.DB.get('rlv:'+await sha(ip)))return J({error:'slow'},429);await env.DB.put('rlv:'+await sha(ip),'1',{expirationTtl:60});
const all=await rd(env,'venues');const v={id:b.id,name:clean(b.name,120),city:clean(b.city,60),country:'Germany',type:'Venue',claimed:false,real:1,g:null};
if(!all.find(x=>x.id===v.id)){all.push(v);await env.DB.put('venues',JSON.stringify(all.slice(-2000)))}return J(v)}
if(u.pathname==='/api/report'&&req.method==='POST'){let b;try{b=await req.json()}catch(e){return J({error:'bad'},400)}
const v=String(b.v||'');if(!/^[\w-]{1,200}$/.test(v))return J({error:'venue'},400);
const pr=clean(b.pr,300),de=clean(b.de,500),p=Math.round(+b.p);if(pr.length<5||de.length<5||!(p>=1&&p<=5))return J({error:'invalid'},400);
const f=(Array.isArray(b.f)?b.f:[]).filter(x=>FL.includes(x)).slice(0,8);
const h=await sha(ip+'|'+v),i=await sha(ip);
if(await env.DB.get('rv:'+h))return J({error:'duplicate'},429);if(await env.DB.get('rl:'+i))return J({error:'slow'},429);
await env.DB.put('rv:'+h,'1',{expirationTtl:2592000});await env.DB.put('rl:'+i,'1',{expirationTtl:60});
const all=await rd(env,'reports');const r={sid:crypto.randomUUID(),v,ver:0,s:p,t:p,p,f,pr,de,tx:'',date:new Date().toISOString().slice(0,7),res:f.length?'open':'none',resp:null,pend:1};
all.push(r);await env.DB.put('reports',JSON.stringify(all.slice(-2000)));return J(r)}
return new Response(new Blob([Uint8Array.from(atob(B64),c=>c.charCodeAt(0))]).stream().pipeThrough(new DecompressionStream('gzip')),{headers:{'content-type':'text/html;charset=utf-8'}})}};
